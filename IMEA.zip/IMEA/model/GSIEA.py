# import types
# import torch
# import transformers
# import torch.nn.functional as F
# import torch.nn as nn
# from torch.nn import CrossEntropyLoss
# import numpy as np
# import pdb
# import math

# from .Tool_model import AutomaticWeightedLoss
# from .GSIEA_tools import MultiModalEncoder
# from .GSIEA_loss import CustomMultiLossLayer, icl_loss
# from src.utils import pairwise_distances


# class GSIEA(nn.Module):
#     def __init__(self, kgs, args):
#         super().__init__()
#         self.kgs = kgs
#         self.args = args

#         self.img_features = F.normalize(torch.FloatTensor(kgs["images_list"])).cuda()
#         self.input_idx = kgs["input_idx"].cuda()
#         self.adj = kgs["adj"].cuda()
#         self.rel_features = torch.Tensor(kgs["rel_features"]).cuda()
#         self.att_features = torch.Tensor(kgs["att_features"]).cuda()

#         self.bow_dim = kgs["bow_dim"]
#         self.bert_dim = self.att_features.shape[1] - self.bow_dim

#         self.bert_projection = nn.Linear(self.bert_dim, self.bow_dim).cuda()
#         self.bert_scale = nn.Parameter(torch.tensor(-4.0))
#         self.bert_aux_weight = 0.01

#         self.name_features = None
#         self.char_features = None
#         if kgs["name_features"] is not None:
#             self.name_features = kgs["name_features"].cuda()
#             self.char_features = kgs["char_features"].cuda()

#         img_dim = self._get_img_dim(kgs)
#         char_dim = kgs["char_features"].shape[1] if self.char_features is not None else 100

#         self.multimodal_encoder = MultiModalEncoder(
#             args=self.args,
#             ent_num=kgs["ent_num"],
#             img_feature_dim=img_dim,
#             char_feature_dim=char_dim,
#             use_project_head=self.args.use_project_head,
#             attr_input_dim=self.bow_dim,
#         )

#         self.multi_loss_layer = CustomMultiLossLayer(loss_num=6)
#         self.criterion_cl = icl_loss(
#             tau=self.args.tau,
#             ab_weight=self.args.ab_weight,
#             n_view=2,
#         )
#         self.criterion_cl_joint = icl_loss(
#             tau=self.args.tau,
#             ab_weight=self.args.ab_weight,
#             n_view=2,
#             replay=self.args.replay,
#             neg_cross_kg=self.args.neg_cross_kg,
#         )

#         tmp = -1 * torch.ones(self.input_idx.shape[0], dtype=torch.int64).cuda()
#         self.replay_matrix = torch.stack([self.input_idx, tmp], dim=1).cuda()
#         self.replay_ready = 0
#         self.idx_one = torch.ones(self.args.batch_size, dtype=torch.int64).cuda()
#         self.idx_double = torch.cat([self.idx_one, self.idx_one]).cuda()
#         self.last_num = 1000000000000

#     def forward(self, batch):
#         (
#             gph_emb,
#             img_emb,
#             rel_emb,
#             att_emb,
#             name_emb,
#             char_emb,
#             joint_emb,
#             joint_emb_fz,
#             hidden_states,
#             weight_norm,
#         ) = self.joint_emb_generat(only_joint=False)

#         (
#             gph_emb_hid,
#             rel_emb_hid,
#             att_emb_hid,
#             img_emb_hid,
#             name_emb_hid,
#             char_emb_hid,
#             joint_emb_hid,
#         ) = self.generate_hidden_emb(hidden_states)

#         if self.args.replay:
#             batch = torch.tensor(batch, dtype=torch.int64).cuda()
#             all_ent_batch = torch.cat([batch[:, 0], batch[:, 1]])

#             if not self.replay_ready:
#                 loss_joi, l_neg, r_neg = self.criterion_cl_joint(joint_emb, batch)
#             else:
#                 neg_l = self.replay_matrix[batch[:, 0], self.idx_one[: batch.shape[0]]]
#                 neg_r = self.replay_matrix[batch[:, 1], self.idx_one[: batch.shape[0]]]

#                 neg_l_set = set(neg_l.tolist())
#                 neg_r_set = set(neg_r.tolist())
#                 all_ent_set = set(all_ent_batch.tolist())

#                 neg_l_list = list(neg_l_set - all_ent_set)
#                 neg_r_list = list(neg_r_set - all_ent_set)

#                 neg_l_ipt = torch.tensor(neg_l_list, dtype=torch.int64).cuda()
#                 neg_r_ipt = torch.tensor(neg_r_list, dtype=torch.int64).cuda()

#                 loss_joi, l_neg, r_neg = self.criterion_cl_joint(
#                     joint_emb,
#                     batch,
#                     neg_l_ipt,
#                     neg_r_ipt,
#                 )

#             index = (
#                 all_ent_batch,
#                 self.idx_double[: batch.shape[0] * 2],
#             )
#             new_value = torch.cat([l_neg, r_neg]).cuda()

#             self.replay_matrix = self.replay_matrix.index_put(index, new_value)

#             if self.replay_ready == 0:
#                 num = torch.sum(self.replay_matrix < 0)
#                 if num == self.last_num:
#                     self.replay_ready = 1
#                     print("-----------------------------------------")
#                     print("begin replay!")
#                     print("-----------------------------------------")
#                 else:
#                     self.last_num = num
#         else:
#             loss_joi = self.criterion_cl_joint(joint_emb, batch)

#         in_loss = self.inner_view_loss(
#             gph_emb,
#             rel_emb,
#             att_emb,
#             img_emb,
#             name_emb,
#             char_emb,
#             batch,
#             weight_norm=weight_norm,
#         )

#         out_loss = self.inner_view_loss(
#             gph_emb_hid,
#             rel_emb_hid,
#             att_emb_hid,
#             img_emb_hid,
#             name_emb_hid,
#             char_emb_hid,
#             batch,
#         )

#         bert_aux_emb = self.get_bert_aux_emb()
#         loss_bert_aux = self.criterion_cl(bert_aux_emb, batch)

#         loss_all = loss_joi + in_loss + out_loss + self.bert_aux_weight * loss_bert_aux

#         loss_dic = {
#             "joint_Intra_modal": loss_joi.item(),
#             "Intra_modal": in_loss.item(),
#             "bert_aux_loss": loss_bert_aux.item(),
#             "bert_gamma": (0.03 * torch.sigmoid(self.bert_scale)).item(),
#         }
#         output = {"loss_dic": loss_dic, "emb": joint_emb}

#         return loss_all, output

#     def generate_hidden_emb(self, hidden):
#         gph_emb = F.normalize(hidden[:, 0, :].squeeze(1))
#         rel_emb = F.normalize(hidden[:, 1, :].squeeze(1))
#         att_emb = F.normalize(hidden[:, 2, :].squeeze(1))
#         img_emb = F.normalize(hidden[:, 3, :].squeeze(1))

#         if hidden.shape[1] >= 6:
#             name_emb = F.normalize(hidden[:, 4, :].squeeze(1))
#             char_emb = F.normalize(hidden[:, 5, :].squeeze(1))
#             joint_emb = torch.cat(
#                 [gph_emb, rel_emb, att_emb, img_emb, name_emb, char_emb],
#                 dim=1,
#             )
#         else:
#             name_emb, char_emb = None, None
#             joint_emb = torch.cat([gph_emb, rel_emb, att_emb, img_emb], dim=1)

#         return gph_emb, rel_emb, att_emb, img_emb, name_emb, char_emb, joint_emb

#     def inner_view_loss(
#         self,
#         gph_emb,
#         rel_emb,
#         att_emb,
#         img_emb,
#         name_emb,
#         char_emb,
#         train_ill,
#         weight_norm=None,
#     ):
#         if weight_norm is not None:
#             mod_num = weight_norm.shape[1]
#             weight_norm = weight_norm * mod_num

#             loss_GCN = (
#                 self.criterion_cl(gph_emb, train_ill, weight_norm=weight_norm[:, 0])
#                 if gph_emb is not None
#                 else 0
#             )
#             loss_rel = (
#                 self.criterion_cl(rel_emb, train_ill, weight_norm=weight_norm[:, 1])
#                 if rel_emb is not None
#                 else 0
#             )
#             loss_att = (
#                 self.criterion_cl(att_emb, train_ill, weight_norm=weight_norm[:, 2])
#                 if att_emb is not None
#                 else 0
#             )
#             loss_img = (
#                 self.criterion_cl(img_emb, train_ill, weight_norm=weight_norm[:, 3])
#                 if img_emb is not None
#                 else 0
#             )
#             loss_name = (
#                 self.criterion_cl(name_emb, train_ill, weight_norm=weight_norm[:, 4])
#                 if name_emb is not None
#                 else 0
#             )
#             loss_char = (
#                 self.criterion_cl(char_emb, train_ill, weight_norm=weight_norm[:, 5])
#                 if char_emb is not None
#                 else 0
#             )
#         else:
#             loss_GCN = self.criterion_cl(gph_emb, train_ill) if gph_emb is not None else 0
#             loss_rel = self.criterion_cl(rel_emb, train_ill) if rel_emb is not None else 0
#             loss_att = self.criterion_cl(att_emb, train_ill) if att_emb is not None else 0
#             loss_img = self.criterion_cl(img_emb, train_ill) if img_emb is not None else 0
#             loss_name = self.criterion_cl(name_emb, train_ill) if name_emb is not None else 0
#             loss_char = self.criterion_cl(char_emb, train_ill) if char_emb is not None else 0

#         total_loss = self.multi_loss_layer(
#             [loss_GCN, loss_rel, loss_att, loss_img, loss_name, loss_char]
#         )
#         return total_loss

#     def get_bert_aux_emb(self):
#         bert_feat = self.att_features[:, self.bow_dim :]
#         bert_emb = self.bert_projection(bert_feat)
#         bert_emb = F.normalize(bert_emb, dim=1)
#         return bert_emb

#     def joint_emb_generat(self, only_joint=True):
#         bow_feat = self.att_features[:, : self.bow_dim]
#         bert_feat = self.att_features[:, self.bow_dim :]

#         bert_emb = self.bert_projection(bert_feat)

#         gamma = 0.1 * torch.sigmoid(self.bert_scale)
#         eff_att_features = bow_feat + gamma * bert_emb

#         (
#             gph_emb,
#             img_emb,
#             rel_emb,
#             att_emb,
#             name_emb,
#             char_emb,
#             joint_emb,
#             joint_emb_fz,
#             hidden_states,
#             weight_norm,
#         ) = self.multimodal_encoder(
#             self.input_idx,
#             self.adj,
#             self.img_features,
#             self.rel_features,
#             eff_att_features,
#             self.name_features,
#             self.char_features,
#         )

#         if only_joint:
#             return joint_emb, weight_norm
#         else:
#             return (
#                 gph_emb,
#                 img_emb,
#                 rel_emb,
#                 att_emb,
#                 name_emb,
#                 char_emb,
#                 joint_emb,
#                 joint_emb_fz,
#                 hidden_states,
#                 weight_norm,
#             )

#     def _get_img_dim(self, kgs):
#         if isinstance(kgs["images_list"], list):
#             img_dim = kgs["images_list"][0].shape[1]
#         elif isinstance(kgs["images_list"], np.ndarray) or torch.is_tensor(kgs["images_list"]):
#             img_dim = kgs["images_list"].shape[1]
#         else:
#             img_dim = kgs["images_list"].shape[1]
#         return img_dim

#     def Iter_new_links(self, epoch, left_non_train, final_emb, right_non_train, new_links=None):
#         if new_links is None:
#             new_links = []

#         if len(left_non_train) == 0 or len(right_non_train) == 0:
#             return new_links

#         distance_list = []
#         for i in np.arange(0, len(left_non_train), 1000):
#             d = pairwise_distances(
#                 final_emb[left_non_train[i : i + 1000]],
#                 final_emb[right_non_train],
#             )
#             distance_list.append(d)

#         distance = torch.cat(distance_list, dim=0)
#         preds_l = torch.argmin(distance, dim=1).cpu().numpy().tolist()
#         preds_r = torch.argmin(distance.t(), dim=1).cpu().numpy().tolist()

#         del distance_list, distance, final_emb

#         if (epoch + 1) % (self.args.semi_learn_step * 5) == self.args.semi_learn_step:
#             new_links = [
#                 (left_non_train[i], right_non_train[p])
#                 for i, p in enumerate(preds_l)
#                 if preds_r[p] == i
#             ]
#         else:
#             new_links = [
#                 (left_non_train[i], right_non_train[p])
#                 for i, p in enumerate(preds_l)
#                 if (preds_r[p] == i) and ((left_non_train[i], right_non_train[p]) in new_links)
#             ]

#         return new_links

#     def data_refresh(self, logger, train_ill, test_ill_, left_non_train, right_non_train, new_links=None):
#         if new_links is None:
#             new_links = []

#         if len(new_links) != 0 and len(left_non_train) != 0 and len(right_non_train) != 0:
#             new_links_select = new_links
#             train_ill = np.vstack((train_ill, np.array(new_links_select)))
#             num_true = len([nl for nl in new_links_select if nl in test_ill_])

#             for nl in new_links_select:
#                 left_non_train.remove(nl[0])
#                 right_non_train.remove(nl[1])

#             if self.args.rank == 0:
#                 logger.info(f"#new_links_select:{len(new_links_select)}")
#                 logger.info(f"train_ill.shape:{train_ill.shape}")
#                 logger.info(f"#true_links: {num_true}")
#                 logger.info(f"true link ratio: {(100 * num_true / len(new_links_select)):.1f}%")
#                 logger.info(
#                     f"#entity not in train set: {len(left_non_train)} (left) "
#                     f"{len(right_non_train)} (right)"
#                 )

#             new_links = []
#         else:
#             logger.info("len(new_links) is 0")

#         return left_non_train, right_non_train, train_ill, new_links





import types
import torch
import transformers
import torch.nn.functional as F
import torch.nn as nn
from torch.nn import CrossEntropyLoss
import numpy as np
import pdb
import math

from .Tool_model import AutomaticWeightedLoss
from .GSIEA_tools import MultiModalEncoder
from .GSIEA_loss import CustomMultiLossLayer, icl_loss
from src.utils import pairwise_distances


class GSIEA(nn.Module):
    def __init__(self, kgs, args):
        super().__init__()
        self.kgs = kgs
        self.args = args

        self.img_features = F.normalize(torch.FloatTensor(kgs["images_list"])).cuda()
        self.input_idx = kgs["input_idx"].cuda()
        self.adj = kgs["adj"].cuda()

        # ===== 融合结构重要性创新：读取 data.py 返回的 importance_scores =====
        if "importance_scores" in kgs:
            self.importance_scores = torch.FloatTensor(kgs["importance_scores"]).cuda()
        else:
            self.importance_scores = None

        self.rel_features = torch.Tensor(kgs["rel_features"]).cuda()
        self.att_features = torch.Tensor(kgs["att_features"]).cuda()

        self.bow_dim = kgs["bow_dim"]
        self.bert_dim = self.att_features.shape[1] - self.bow_dim

        self.bert_projection = nn.Linear(self.bert_dim, self.bow_dim).cuda()
        # self.bert_scale = nn.Parameter(torch.tensor(-4.0))
        self.bert_max_scale = 0.10

        # 固定初始 gamma，使不同配置具有相同的初始融合强度
        gamma_init = 0.10 * torch.sigmoid(torch.tensor(-4.0))

        self.bert_scale = nn.Parameter(
            torch.logit(gamma_init / self.bert_max_scale)
        )
        self.bert_aux_weight = 0.01

        self.name_features = None
        self.char_features = None
        if kgs["name_features"] is not None:
            self.name_features = kgs["name_features"].cuda()
            self.char_features = kgs["char_features"].cuda()

        img_dim = self._get_img_dim(kgs)
        char_dim = kgs["char_features"].shape[1] if self.char_features is not None else 100

        self.multimodal_encoder = MultiModalEncoder(
            args=self.args,
            ent_num=kgs["ent_num"],
            img_feature_dim=img_dim,
            char_feature_dim=char_dim,
            use_project_head=self.args.use_project_head,
            attr_input_dim=self.bow_dim,
        )

        self.multi_loss_layer = CustomMultiLossLayer(loss_num=6)
        self.criterion_cl = icl_loss(
            tau=self.args.tau,
            ab_weight=self.args.ab_weight,
            n_view=2,
        )
        self.criterion_cl_joint = icl_loss(
            tau=self.args.tau,
            ab_weight=self.args.ab_weight,
            n_view=2,
            replay=self.args.replay,
            neg_cross_kg=self.args.neg_cross_kg,
        )

        tmp = -1 * torch.ones(self.input_idx.shape[0], dtype=torch.int64).cuda()
        self.replay_matrix = torch.stack([self.input_idx, tmp], dim=1).cuda()
        self.replay_ready = 0
        self.idx_one = torch.ones(self.args.batch_size, dtype=torch.int64).cuda()
        self.idx_double = torch.cat([self.idx_one, self.idx_one]).cuda()
        self.last_num = 1000000000000

    def forward(self, batch):
        (
            gph_emb,
            img_emb,
            rel_emb,
            att_emb,
            name_emb,
            char_emb,
            joint_emb,
            joint_emb_fz,
            hidden_states,
            weight_norm,
        ) = self.joint_emb_generat(
            only_joint=False,
            importance_scores=self.importance_scores,
        )

        (
            gph_emb_hid,
            rel_emb_hid,
            att_emb_hid,
            img_emb_hid,
            name_emb_hid,
            char_emb_hid,
            joint_emb_hid,
        ) = self.generate_hidden_emb(hidden_states)

        if self.args.replay:
            batch = torch.tensor(batch, dtype=torch.int64).cuda()
            all_ent_batch = torch.cat([batch[:, 0], batch[:, 1]])

            if not self.replay_ready:
                loss_joi, l_neg, r_neg = self.criterion_cl_joint(joint_emb, batch)
            else:
                neg_l = self.replay_matrix[batch[:, 0], self.idx_one[: batch.shape[0]]]
                neg_r = self.replay_matrix[batch[:, 1], self.idx_one[: batch.shape[0]]]

                neg_l_set = set(neg_l.tolist())
                neg_r_set = set(neg_r.tolist())
                all_ent_set = set(all_ent_batch.tolist())

                neg_l_list = list(neg_l_set - all_ent_set)
                neg_r_list = list(neg_r_set - all_ent_set)

                neg_l_ipt = torch.tensor(neg_l_list, dtype=torch.int64).cuda()
                neg_r_ipt = torch.tensor(neg_r_list, dtype=torch.int64).cuda()

                loss_joi, l_neg, r_neg = self.criterion_cl_joint(
                    joint_emb,
                    batch,
                    neg_l_ipt,
                    neg_r_ipt,
                )

            index = (
                all_ent_batch,
                self.idx_double[: batch.shape[0] * 2],
            )
            new_value = torch.cat([l_neg, r_neg]).cuda()

            self.replay_matrix = self.replay_matrix.index_put(index, new_value)

            if self.replay_ready == 0:
                num = torch.sum(self.replay_matrix < 0)
                if num == self.last_num:
                    self.replay_ready = 1
                    print("-----------------------------------------")
                    print("begin replay!")
                    print("-----------------------------------------")
                else:
                    self.last_num = num
        else:
            loss_joi = self.criterion_cl_joint(joint_emb, batch)

        in_loss = self.inner_view_loss(
            gph_emb,
            rel_emb,
            att_emb,
            img_emb,
            name_emb,
            char_emb,
            batch,
            weight_norm=weight_norm,
        )

        out_loss = self.inner_view_loss(
            gph_emb_hid,
            rel_emb_hid,
            att_emb_hid,
            img_emb_hid,
            name_emb_hid,
            char_emb_hid,
            batch,
        )

        bert_aux_emb = self.get_bert_aux_emb()
        loss_bert_aux = self.criterion_cl(bert_aux_emb, batch)

        loss_all = loss_joi + in_loss + out_loss + self.bert_aux_weight * loss_bert_aux

        loss_dic = {
            "joint_Intra_modal": loss_joi.item(),
            "Intra_modal": in_loss.item(),
            "bert_aux_loss": loss_bert_aux.item(),
            # "bert_gamma": (0.1 * torch.sigmoid(self.bert_scale)).item(),
            "bert_gamma": (
            self.bert_max_scale * torch.sigmoid(self.bert_scale)
        ).item(),
        }
        output = {"loss_dic": loss_dic, "emb": joint_emb}

        return loss_all, output

    def generate_hidden_emb(self, hidden):
        gph_emb = F.normalize(hidden[:, 0, :].squeeze(1))
        rel_emb = F.normalize(hidden[:, 1, :].squeeze(1))
        att_emb = F.normalize(hidden[:, 2, :].squeeze(1))
        img_emb = F.normalize(hidden[:, 3, :].squeeze(1))

        if hidden.shape[1] >= 6:
            name_emb = F.normalize(hidden[:, 4, :].squeeze(1))
            char_emb = F.normalize(hidden[:, 5, :].squeeze(1))
            joint_emb = torch.cat(
                [gph_emb, rel_emb, att_emb, img_emb, name_emb, char_emb],
                dim=1,
            )
        else:
            name_emb, char_emb = None, None
            joint_emb = torch.cat([gph_emb, rel_emb, att_emb, img_emb], dim=1)

        return gph_emb, rel_emb, att_emb, img_emb, name_emb, char_emb, joint_emb

    def inner_view_loss(
        self,
        gph_emb,
        rel_emb,
        att_emb,
        img_emb,
        name_emb,
        char_emb,
        train_ill,
        weight_norm=None,
    ):
        if weight_norm is not None:
            mod_num = weight_norm.shape[1]
            weight_norm = weight_norm * mod_num

            loss_GCN = (
                self.criterion_cl(gph_emb, train_ill, weight_norm=weight_norm[:, 0])
                if gph_emb is not None
                else 0
            )
            loss_rel = (
                self.criterion_cl(rel_emb, train_ill, weight_norm=weight_norm[:, 1])
                if rel_emb is not None
                else 0
            )
            loss_att = (
                self.criterion_cl(att_emb, train_ill, weight_norm=weight_norm[:, 2])
                if att_emb is not None
                else 0
            )
            loss_img = (
                self.criterion_cl(img_emb, train_ill, weight_norm=weight_norm[:, 3])
                if img_emb is not None
                else 0
            )
            loss_name = (
                self.criterion_cl(name_emb, train_ill, weight_norm=weight_norm[:, 4])
                if name_emb is not None
                else 0
            )
            loss_char = (
                self.criterion_cl(char_emb, train_ill, weight_norm=weight_norm[:, 5])
                if char_emb is not None
                else 0
            )
        else:
            loss_GCN = self.criterion_cl(gph_emb, train_ill) if gph_emb is not None else 0
            loss_rel = self.criterion_cl(rel_emb, train_ill) if rel_emb is not None else 0
            loss_att = self.criterion_cl(att_emb, train_ill) if att_emb is not None else 0
            loss_img = self.criterion_cl(img_emb, train_ill) if img_emb is not None else 0
            loss_name = self.criterion_cl(name_emb, train_ill) if name_emb is not None else 0
            loss_char = self.criterion_cl(char_emb, train_ill) if char_emb is not None else 0

        total_loss = self.multi_loss_layer(
            [loss_GCN, loss_rel, loss_att, loss_img, loss_name, loss_char]
        )
        return total_loss

    def get_bert_aux_emb(self):
        bert_feat = self.att_features[:, self.bow_dim :]
        bert_emb = self.bert_projection(bert_feat)
        bert_emb = F.normalize(bert_emb, dim=1)
        return bert_emb

    def joint_emb_generat(self, only_joint=True, importance_scores=None):
        bow_feat = self.att_features[:, : self.bow_dim]
        bert_feat = self.att_features[:, self.bow_dim :]

        bert_emb = self.bert_projection(bert_feat)

        # gamma = 0.1 * torch.sigmoid(self.bert_scale)
        gamma = self.bert_max_scale * torch.sigmoid(self.bert_scale)
        eff_att_features = bow_feat + gamma * bert_emb

        (
            gph_emb,
            img_emb,
            rel_emb,
            att_emb,
            name_emb,
            char_emb,
            joint_emb,
            joint_emb_fz,
            hidden_states,
            weight_norm,
        ) = self.multimodal_encoder(
            self.input_idx,
            self.adj,
            self.img_features,
            self.rel_features,
            eff_att_features,
            self.name_features,
            self.char_features,
            importance_scores=importance_scores,
        )

        if only_joint:
            return joint_emb, weight_norm
        else:
            return (
                gph_emb,
                img_emb,
                rel_emb,
                att_emb,
                name_emb,
                char_emb,
                joint_emb,
                joint_emb_fz,
                hidden_states,
                weight_norm,
            )

    def _get_img_dim(self, kgs):
        if isinstance(kgs["images_list"], list):
            img_dim = kgs["images_list"][0].shape[1]
        elif isinstance(kgs["images_list"], np.ndarray) or torch.is_tensor(kgs["images_list"]):
            img_dim = kgs["images_list"].shape[1]
        else:
            img_dim = kgs["images_list"].shape[1]
        return img_dim

    def Iter_new_links(self, epoch, left_non_train, final_emb, right_non_train, new_links=None):
        if new_links is None:
            new_links = []

        if len(left_non_train) == 0 or len(right_non_train) == 0:
            return new_links

        distance_list = []
        for i in np.arange(0, len(left_non_train), 1000):
            d = pairwise_distances(
                final_emb[left_non_train[i : i + 1000]],
                final_emb[right_non_train],
            )
            distance_list.append(d)

        distance = torch.cat(distance_list, dim=0)
        preds_l = torch.argmin(distance, dim=1).cpu().numpy().tolist()
        preds_r = torch.argmin(distance.t(), dim=1).cpu().numpy().tolist()

        del distance_list, distance, final_emb

        if (epoch + 1) % (self.args.semi_learn_step * 5) == self.args.semi_learn_step:
            new_links = [
                (left_non_train[i], right_non_train[p])
                for i, p in enumerate(preds_l)
                if preds_r[p] == i
            ]
        else:
            new_links = [
                (left_non_train[i], right_non_train[p])
                for i, p in enumerate(preds_l)
                if (preds_r[p] == i) and ((left_non_train[i], right_non_train[p]) in new_links)
            ]

        return new_links

    def data_refresh(self, logger, train_ill, test_ill_, left_non_train, right_non_train, new_links=None):
        if new_links is None:
            new_links = []

        if len(new_links) != 0 and len(left_non_train) != 0 and len(right_non_train) != 0:
            new_links_select = new_links
            train_ill = np.vstack((train_ill, np.array(new_links_select)))
            num_true = len([nl for nl in new_links_select if nl in test_ill_])

            for nl in new_links_select:
                left_non_train.remove(nl[0])
                right_non_train.remove(nl[1])

            if self.args.rank == 0:
                logger.info(f"#new_links_select:{len(new_links_select)}")
                logger.info(f"train_ill.shape:{train_ill.shape}")
                logger.info(f"#true_links: {num_true}")
                logger.info(f"true link ratio: {(100 * num_true / len(new_links_select)):.1f}%")
                logger.info(
                    f"#entity not in train set: {len(left_non_train)} (left) "
                    f"{len(right_non_train)} (right)"
                )

            new_links = []
        else:
            logger.info("len(new_links) is 0")

        return left_non_train, right_non_train, train_ill, new_links
